<?php
    $hostname = "localhost";
    $user = "root";
    $password = "";
    $dbname ="simak";
    $conn = mysqli_connect($hostname,$user,$password,$dbname) or die('connection failed');
?>